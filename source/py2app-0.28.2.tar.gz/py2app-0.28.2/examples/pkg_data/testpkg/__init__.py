from __future__ import print_function
import os
print(open(os.path.join(os.path.dirname(__file__), 'data.txt')).read())
