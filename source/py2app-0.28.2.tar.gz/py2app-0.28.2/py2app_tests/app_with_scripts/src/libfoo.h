/* Helper module */

extern int square(int value);
