import curses
print("Helper 1: %s"%(curses.__name__,))
