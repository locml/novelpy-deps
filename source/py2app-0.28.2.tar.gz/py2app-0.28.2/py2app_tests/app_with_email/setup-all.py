from setuptools import setup

setup(
    name='BasicApp',
    app=['main-all.py'],
)
