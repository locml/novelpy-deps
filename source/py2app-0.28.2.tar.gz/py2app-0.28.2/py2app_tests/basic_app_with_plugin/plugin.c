int plugin(void)
{
   return 42;
}
