import __init__

from modulegraph.find_modules import find_needed_modules
import distutils
