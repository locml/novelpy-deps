from setuptools import setup

setup(
        name="nameduser",
        version="1.5",
        packages=["namedpkg"],
        namespace_packages=["namedpkg"],
)
