:mod:`macholib.MachoGraph` --- Graph data structure of Mach-O dependencies
===============================================================================

.. module:: macholib.MachOGraph
   :synopsis: Graph data structure of Mach-O dependencies

This module defines the class :class:`MachOGraph` which represents the
direct and indirect dependencies of one or more  Mach-O files on
other (library) files.

.. class:: MachOGraph(...)

   To be discussed.
