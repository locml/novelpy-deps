---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: tkem

---

Sorry, but `cachetools` is not accepting feature requests at this time.
