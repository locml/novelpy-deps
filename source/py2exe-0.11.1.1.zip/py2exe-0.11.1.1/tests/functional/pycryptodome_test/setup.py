from distutils.core import setup
import py2exe

setup(console=[{"script": "pycryptodome_test.py"}])
