from distutils.core import setup
import py2exe

setup(console=[{ "script": "zope_interface_test.py"}])
