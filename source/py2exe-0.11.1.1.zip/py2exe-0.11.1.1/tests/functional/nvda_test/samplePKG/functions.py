def my_avesome_func(param):
	print(param)
